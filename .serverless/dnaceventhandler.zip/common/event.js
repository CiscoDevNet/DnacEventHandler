/**
 * Copyright 2018 Cisco Systems
 *
 * Author: haihxiao@cisco.com
 **/

const EventEmitter = require('events');

module.exports = exports = new EventEmitter();
